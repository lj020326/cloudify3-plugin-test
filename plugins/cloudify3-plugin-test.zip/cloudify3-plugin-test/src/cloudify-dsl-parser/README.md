Cloudify DSL Parser
===================

* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-dsl-parser.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-dsl-parser)
* PyPI [![PyPI](http://img.shields.io/pypi/dm/cloudify-dsl-parser.svg)](http://img.shields.io/pypi/dm/cloudify-dsl-parser.svg)
* Version [![PypI](http://img.shields.io/pypi/v/cloudify-dsl-parser.svg)](http://img.shields.io/pypi/v/cloudify-dsl-parser.svg)


Cloudify DSL parsing package

## Reference
For details on the DSL specification see [DSL Specification](http://getcloudify.org/guide/dsl-spec-general.html).
