cosmo-plugin-dsl-parser
=======================

This package contains a plugin that manipulates the recipe dsl

-  Build Status (master) |Build Status|

.. |Build Status| image:: https://secure.travis-ci.org/CloudifySource/cosmo-plugin-dsl-parser.png?branch=master
   :target: http://travis-ci.org/CloudifySource/cosmo-plugin-dsl-parser
