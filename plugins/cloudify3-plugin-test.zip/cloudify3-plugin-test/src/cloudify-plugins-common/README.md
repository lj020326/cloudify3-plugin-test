# Cloudify Plugins Common

* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-plugins-common.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-plugins-common)
* PyPI [![PyPI](http://img.shields.io/pypi/dm/cloudify-plugins-common.svg)](http://img.shields.io/pypi/dm/cloudify-plugins-common.svg)
* Version [![PypI](http://img.shields.io/pypi/v/cloudify-plugins-common.svg)](http://img.shields.io/pypi/v/cloudify-plugins-common.svg)


This package contains common modules that are mandatory for Cloudify's plugins.

See [ReadTheDocs](http://cloudify-plugins-common.readthedocs.org/en/latest/) for an API reference.