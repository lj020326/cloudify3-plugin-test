Cloudify Plugins Common
=======================

This package contains common modules that need to be used by plugins.

-  Build Status (master branch) |Build Status|

.. |Build Status| image:: https://secure.travis-ci.org/cloudify-cosmo/cloudify-plugins-common.png?branch=master
   :target: http://travis-ci.org/cloudify-cosmo/cloudify-plugins-common

