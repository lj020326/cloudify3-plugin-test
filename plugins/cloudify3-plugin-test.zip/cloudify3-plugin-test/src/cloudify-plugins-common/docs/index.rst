.. cloudify-cli documentation master file, created by
   sphinx-quickstart on Thu Jun 12 15:30:03 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cloudify-plugin-common's documentation!
==================================================

This is the API reference to the cloudify-plugins-common module which is required when writing any cloudify plugin (and workflow).

Contents:

.. toctree::
   :maxdepth: 2

   context
   decorators
   exceptions
   manager
   mocks
   utils
   logs
   workflows

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

