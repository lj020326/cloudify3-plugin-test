=======
Manager
=======

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify.manager
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: DirtyTrackingDict, get_host_node_instance_ip, dirty, host_id, version, get, put