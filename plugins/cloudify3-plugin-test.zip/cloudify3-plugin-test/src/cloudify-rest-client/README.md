Cloudify REST Client
====================

* Master Branch [![Build Status](https://travis-ci.org/cloudify-cosmo/cloudify-rest-client.svg?branch=master)](https://travis-ci.org/cloudify-cosmo/cloudify-rest-client)
* PyPI [![PyPI](http://img.shields.io/pypi/dm/cloudify-rest-client.svg)](http://img.shields.io/pypi/dm/cloudify-rest-client.svg)
* Version [![PypI](http://img.shields.io/pypi/v/cloudify-rest-client.svg)](http://img.shields.io/pypi/v/cloudify-rest-client.svg)


Client for interacting with Cloudify's management machine.

See [http://cloudify-rest-client.readthedocs.org/en/latest/](http://cloudify-rest-client.readthedocs.org/en/latest/)