Cloudify REST Client
====================

Client for interacting with Cloudify's management machine.
