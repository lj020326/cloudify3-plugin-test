==============
Blueprints API
==============

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.blueprints
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: CONTENT_DISPOSITION_HEADER
