==========
Client API
==========

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.client
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: HTTPClient