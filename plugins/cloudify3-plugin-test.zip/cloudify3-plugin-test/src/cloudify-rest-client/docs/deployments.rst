===============
Deployments API
===============

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.deployments
   :members:
   :undoc-members:
   :show-inheritance: