============
Evaluate API
============

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.evaluate
   :members:
   :undoc-members:
   :show-inheritance:
