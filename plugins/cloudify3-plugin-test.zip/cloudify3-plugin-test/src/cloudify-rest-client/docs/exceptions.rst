==============
Exceptions API
==============

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.exceptions
   :members:
   :undoc-members:
   :show-inheritance: