==============
Executions API
==============

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.executions
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: TERMINATED, FAILED, CANCELLED, PENDING, STARTED, CANCELLING, FORCE_CANCELLING, END_STATES