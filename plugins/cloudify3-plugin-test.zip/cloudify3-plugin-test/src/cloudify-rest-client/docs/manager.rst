===========
Manager API
===========

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.manager
   :members:
   :undoc-members:
   :show-inheritance: