==========
Search API
==========

.. toctree::
   :maxdepth: 2

.. automodule:: cloudify_rest_client.search
   :members:
   :undoc-members:
   :show-inheritance:
